<?php
include 'db/db_connect.php';
$movieArray = array();
$response = array();

if(isset($_GET['movie_id'])){
	$movieId = $_GET['movie_id'];

	$query = "SELECT movie_name, genre, year, rating FROM movies WHERE movie_id=?";
	if($stmt = $con->prepare($query)){
		
		$stmt->bind_param("i",$movieId);
		$stmt->execute();
		
		$stmt->bind_result($movieName,$genre,$year,$rating);
				
		if($stmt->fetch()){
		
			$movieArray["movie_id"] = $movieId;
			$movieArray["movie_name"] = $movieName;
			$movieArray["genre"] = $genre;
			$movieArray["year"] = $year;
			$movieArray["rating"] = round($rating,1);
			$response["success"] = 1;
			$response["data"] = $movieArray;
		
		
		}else{
		
			$response["success"] = 0;
			$response["message"] = "Filme nao encontrado!!!";
		}
		$stmt->close();
 
 
	}else{
		//Whe some error occurs
		$response["success"] = 0;
		$response["message"] = mysqli_error($con);
		
	}
 
}else{
	
	$response["success"] = 0;
	$response["message"] = "Parâmetro ausente movie_id";
}

echo json_encode($response);
?>