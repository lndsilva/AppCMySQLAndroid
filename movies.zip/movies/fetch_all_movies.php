<?php
include 'db/db_connect.php';

$query = "SELECT movie_id, movie_name FROM movies";
$result = array();
$movieArray = array();
$response = array();

if($stmt = $con->prepare($query)){
	$stmt->execute();

	$stmt->bind_result($movieId,$movieName);
					
	while($stmt->fetch()){
		
		$movieArray["movie_id"] = $movieId;
		$movieArray["movie_name"] = $movieName;
		$result[]=$movieArray;
		
	}
	$stmt->close();
	$response["success"] = 1;
	$response["data"] = $result;
	
 
}else{
	
	$response["success"] = 0;
	$response["message"] = mysqli_error($con);
		
	
}

echo json_encode($response);
 
?>