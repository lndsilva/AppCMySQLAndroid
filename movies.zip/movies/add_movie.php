<?php
include 'db/db_connect.php';
$response = array();


if(isset($_POST['movie_name'])&&isset($_POST['genre'])&&isset($_POST['year'])&&isset($_POST['rating'])){
	$movieName = $_POST['movie_name'];
	$genre = $_POST['genre'];
	$year = $_POST['year'];
	$rating = $_POST['rating'];
	

	$query = "INSERT INTO movies( movie_name, genre, year, rating) VALUES (?,?,?,?)";

	if($stmt = $con->prepare($query)){

		$stmt->bind_param("ssis",$movieName,$genre,$year,$rating);

		$stmt->execute();

		if($stmt->affected_rows == 1){
			$response["success"] = 1;			
			$response["message"] = "Filme adiconado com sucesso!!!";			
			
		}else{
			
			$response["success"] = 0;
			$response["message"] = "Erro ao adicionar um filme!!!";
		}					
	}else{
		
		$response["success"] = 0;
		$response["message"] = mysqli_error($con);
	}

}else{
	
	$response["success"] = 0;
	$response["message"] = "Parâmetros obrigatórios ausentes.";
}

echo json_encode($response);
?>