<?php
include 'db/db_connect.php';
$response = array();

if(isset($_POST['movie_id'])){
	$movieId = $_POST['movie_id'];
	$query = "DELETE FROM movies WHERE movie_id=?";
	if($stmt = $con->prepare($query)){

		$stmt->bind_param("i",$movieId);
		$stmt->execute();

		if($stmt->affected_rows == 1){
			$response["success"] = 1;			
			$response["message"] = "Filme excluido com sucesso!!!";
			
		}else{
			$response["success"] = 0;
			$response["message"] = "Filme nao encontrado.";
		}					
	}else{
		$response["success"] = 0;
		$response["message"] = mysqli_error($con);
	}
 
}else{
	$response["success"] = 0;
	$response["message"] = "Parametro ausente para movie_id";
}
echo json_encode($response);
?>