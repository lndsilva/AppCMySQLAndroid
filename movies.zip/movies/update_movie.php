<?php
include 'db/db_connect.php';
$response = array();
 

if(isset($_POST['movie_name'])&&isset($_POST['movie_id'])&&isset($_POST['genre'])&&isset($_POST['year'])&&isset($_POST['rating'])){
	$movieName = $_POST['movie_name'];
	$movieId = $_POST['movie_id'];
	$genre = $_POST['genre'];
	$year = $_POST['year'];
	$rating = $_POST['rating'];
	

	$query = "UPDATE movies SET movie_name=?,genre=?,year=?,rating=? WHERE movie_id=?";

	if($stmt = $con->prepare($query)){

		$stmt->bind_param("ssisi",$movieName,$genre,$year,$rating,$movieId);

		$stmt->execute();

		if($stmt->affected_rows == 1){
			$response["success"] = 1;			
			$response["message"] = "Filme alterado com sucesso!!!";
			
		}else{

			$response["success"] = 0;
			$response["message"] = "Filme nao encontrado.";
		}					
	}else{

		$response["success"] = 0;
		$response["message"] = mysqli_error($con);
	}
 
}else{

	$response["success"] = 0;
	$response["message"] = "Parâmetros obrigatórios não encontrados.";
}

echo json_encode($response);
?>